The new update process of Financial Planning & Information Services involves making trade recommendations through Morningstar's TRX platform, and then exporting the .csv file of this in order to make a report to sent to the client. Within this folder is a sample export of the recommendations, and the Excel sheet used to call the macro

------------
INSTRUCTIONS
------------
1. In Microsoft Excel, open the sample portfolio and the sample .csv files
2. Open the VBA editor through the Developer tab in the ribbon, or press Alt+F11
3. Go to file > import, and import each of the .bas files