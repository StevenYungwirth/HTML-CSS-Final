As part of the update process of Financial Planning & Information Services, the client's portfolio in Excel had to be updated to the current market value of their investments. Included in this folder is a sample portfolio, along with sample exports from TD Ameritrade's Veo platform. The macros enclosed are designed to be run when the client’s portfolio sheet is open, along with the exported .csv files from each of their TD Ameritrade accounts. The update process is split into three parts:

1. The first macro (AllTDSheets) formats each sheet for printing (used as a double-check), deletes unnecessary transactions (only keeping the money in and out since that is what was reported to the clients), and copies the account position values onto the client’s portfolio sheet. If new funds are added or old ones are removed, the macro will adjust the portfolio sheet as necessary.

2. The second macro (Dist) asks for the total money in and/or out of the portfolio, ensures that necessary formulas on the sheets are correct, and adds a new line with formulas for the client’s portfolio performance. It then calls the third macro before printing off each sheet.

3. The last part (Grid_Sort) makes sure the Grid sheet is formatted correctly, and then sorts each sector alphabetically. It then makes sure the total equities match between the Grid sheet and the Portfolio sheet before returning to the second Macro to print.

------------
INSTRUCTIONS
------------
1. In Microsoft Excel, open the sample portfolio and the sample .csv files
2. Open the VBA editor through the Developer tab in the ribbon, or press Alt+F11
3. Go to file > import, and import each of the .bas, .frm, and .frx files
4. In the Portfolio tab, run the AllTDSheets macro by pressing the Start button in the VBA editor, or the default shortcut key, Ctrl+Shift+H
(Optional) The Grid_Sort macro is called from the Dist macro, but if you would like to run it by itself, then in the Grid tab, run the Grid_Sort macro by pressing the Start button in the VBA editor, or the default shortcut key, Ctrl+Shift+F
5. In the Dist tab, run the Dist macro by pressing the Start button in the VBA editor, or the default shortcut key, Ctrl+Shift+A